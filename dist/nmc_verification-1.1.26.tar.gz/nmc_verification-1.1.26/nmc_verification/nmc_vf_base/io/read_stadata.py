#!/usr/bin/python3.6
# -*- coding:UTF-8 -*-
import numpy as np
import os
import pandas as pd
import nmc_verification
import traceback
import re
import copy
from . import DataBlock_pb2
from .GDS_data_service import GDSDataService
import struct
from collections import OrderedDict
import datetime

def read_station(filename):
    '''
    :param filename: 站点文件路径，它可以是micaps第1、2、3、8类文件
    :return: 站点数据，其中time,dtime,level属性为设置的缺省值，数据内容都设置为0
    '''
    sta = None
    if os.path.exists(filename):
        file = open(filename,'r')
        head = file.readline()
        strs = head.split()

        if strs[1] == "3":
            sta = read_stadata_from_micaps3(filename)
        elif strs[1] == "16":
            sta = read_stadata_from_micaps16(filename)
        elif strs[1] == "1" or str[1] == "2" or str[1] == "8":
            sta = read_stadata_from_micaps1_2_8(filename,column=4)
        else:
            print(filename + "is not micaps第1、2、3、8类文件")
    else:
        print(filename + " not exist")
    if sta is not None:
        data_name = sta.columns[-1]
        sta[data_name] = 0
        nmc_verification.nmc_vf_base.set_stadata_coords(sta,time = datetime.datetime(2099,1,1,8,0),level = 0,dtime= 0)
        return sta

def read_stadata_from_micaps3(filename, station=None,  level=None,time=None, dtime=None, data_name='data0', drop_same_id=True):
    '''
    读取micaps3格式文件转换为pandas中dataframe结构的数据

    :param reserve_time_dtime_level:保留时间，时效和层次，默认为rue
    :param data_name:dataframe中数值的values列的名称
    :return:返回一个dataframe结构的多列站点数据。
    :param filename: 文件路径
    :param station: 站号，默认：None
    :param time: 起报时  默认：NOne
    :param dtime: 时效 默认：None
    :param level:  层次  默认：None
    :param data_name: 要素名  默认：'data0'
    :param drop_same_id: 是否要删除相同id的行  默认为True
    :return:
    '''
    try:
        if os.path.exists(filename):
            file = open(filename, 'r')
            skip_num = 0
            strs = []
            nline = 0
            nregion = 0
            nstart = 0
            while 1 > 0:
                skip_num += 1
                str1 = file.readline()
                strs.extend(str1.split())

                if (len(strs) > 8):
                    nline = int(strs[8])
                if (len(strs) > 11 + nline):
                    nregion = int(strs[11 + nline])
                    nstart = nline + 2 * nregion + 14
                    if (len(strs) == nstart):
                        break
            file.close()

            file_sta = open(filename)

            sta1 = pd.read_csv(file_sta, skiprows=skip_num, sep="\s+", header=None, usecols=[0, 1, 2, 4])
            sta1.columns = ['id', 'lon', 'lat', data_name]
            sta1.drop_duplicates(keep='first', inplace=True)
            if drop_same_id:
                sta1 = sta1.drop_duplicates(['id'])
            # sta = bd.sta_data(sta1)
            sta = nmc_verification.nmc_vf_base.basicdata.sta_data(sta1)
            # print(sta)

            y2 = ""
            if len(strs[3]) == 2:
                year = int(strs[3])
                if year >= 50:
                    y2 = '19'
                else:
                    y2 = '20'
            if len(strs[3]) == 1: strs[3] = "0" + strs[3]
            if len(strs[4]) == 1: strs[4] = "0" + strs[4]
            if len(strs[5]) == 1: strs[5] = "0" + strs[5]
            if len(strs[6]) == 1: strs[6] = "0" + strs[6]

            time_str = y2 + strs[3] + strs[4] + strs[5] + strs[6]
            time_file = nmc_verification.nmc_vf_base.tool.time_tools.str_to_time(time_str)
            sta.loc[:,"time"] = time_file
            sta.loc[:,"dtime"] = 0
            sta.loc[:,"level"] = 0 #int(strs[7])
            nmc_verification.nmc_vf_base.set_stadata_coords(sta, level=level, time=time, dtime=dtime)

            if (station is not None):
                sta = nmc_verification.nmc_vf_base.put_stadata_on_station(sta, station)
            return sta
        else:
            return None
    except:
        exstr = traceback.format_exc()
        print(exstr)
        return None

def read_stadata_from_txt(filename, columns , skiprows=0, drop_same_id=True):

    """
    读取站点数据
    :param filename:带有站点信息的路径已经文件名
    :param columns 列名
    :param skiprows:读取时跳过的行数，默认为：0
    :param drop_same_id: 是否要删除相同id的行  默认为True
    :return:返回带有'level','time','dtime','id','lon','lat','alt','data0'列的dataframe站点信息。
    """
    if os.path.exists(filename):
        try:
            file_sta = open(filename, 'r')
            sta0 = pd.read_csv(file_sta, skiprows=skiprows, sep="\s+", header=None)
        except:
            try:
                file_sta = open(filename, 'r', encoding="UTF-8")
                sta0 = pd.read_csv(file_sta, skiprows=skiprows, sep="\s+", header=None)
            except:
                exstr = traceback.format_exc()
                print(exstr)
                return None
        sta0.columns = columns
        station_column = ['id', 'lon', 'lat', 'alt']
        colums1 = []
        for name in station_column:
            if name in columns:
                colums1.append(name)
        sta1 = sta0[colums1]
        nsta = len(sta1.index)
        for i in range(nsta):
            if sta1.loc[i, 'lon'] > 1000:
                a = sta1.loc[i, 'lon'] // 100 + (a % 100) / 60
                sta1.loc[i, 'lon'] = a
            if sta1.loc[i, 'lat'] > 1000:
                a = sta1.loc[i, 'lat'] // 100 + (a % 100) / 60
                sta1.loc[i, 'lat'] = a
        # sta = bd.sta_data(sta1)
        sta = nmc_verification.nmc_vf_base.basicdata.sta_data(sta1)
        if drop_same_id:
            sta = sta.drop_duplicates(['id'])

        # sta['time'] = method.time_tools.str_to_time64("2099010108")
        sta.loc[:,'time'] = nmc_verification.nmc_vf_base.tool.time_tools.str_to_time64("2099010108")
        sta.loc[:,'level'] = 0
        sta.loc[:,'dtime'] = 0
        # sta.coloumns = ['level', 'time', 'dtime', 'id', 'lon', 'lat', 'alt', 'data0']
        sta.loc[:,'data0'] = 0
        nmc_verification.nmc_vf_base.basicdata.reset_id(sta)
        return sta
    else:
        print(filename + " not exist")
        return None


def read_stadata_from_sevp(filename0, element_id,level=None,time=None,data_name = "data0"):
    '''
    兼容多个时次的预报产品文件 txt格式
    :param：filename:文件路径和名称
    :param: element:选取要素
    :param drop_same_id: 是否要删除相同id的行  默认为True
    :return：dataframe格式的站点数据

    '''
    filename = filename0
    try:
        if os.path.exists(filename):
            try:
                file = open(filename, 'r')
                skip_num = 6
                line1 = file.readline()
                line2 = file.readline()
                line3 = file.readline()
                line4 = file.readline()
                line5 = file.readline()
                line6 = file.readline()
                file.close()
            except:
                try:
                    file = open(filename, 'r', encoding="UTF-8")
                    skip_num = 6
                    line1 = file.readline()
                    line2 = file.readline()
                    line3 = file.readline()
                    line4 = file.readline()
                    line5 = file.readline()
                    line6 = file.readline()
                    file.close()
                except:
                    exstr = traceback.format_exc()
                    print(exstr)
                    return None
            try:
                file_sta = open(filename)
                sta1 = pd.read_csv(file_sta, skiprows=skip_num, sep="\s+", header=None)
                file.close()
            except:
                try:
                    file_sta = open(filename, 'r', encoding="UTF-8")
                    sta1 = pd.read_csv(file_sta, skiprows=skip_num, sep="\s+", header=None)
                    file.close()
                except:
                    exstr = traceback.format_exc()
                    print(exstr)
                    return None
            num_list = re.findall(r"\d+", line3)
            strs4 = line4.split()
            time_file = nmc_verification.nmc_vf_base.tool.time_tools.str_to_time(strs4[1])
            line6_list = re.findall(r'[0-9.]+', line6)
            nline0 = int(line6_list[5])
            sta_all = sta1.iloc[0:nline0,[0,element_id]]
            sta_all.loc[:,"id"] = int(line6_list[0])
            sta_all.loc[:,"lon"] = float(line6_list[1])
            sta_all.loc[:,"lat"] = float(line6_list[2])
            #print(sta_all)
            dat_station = sta1.values[nline0,0:5]
            nline_all = len(sta1.index)
            while True:
                nline1 = nline0 + int(dat_station[-1])+1
                sta_one = sta1.iloc[nline0+1:nline1,[0,element_id]]
                sta_one.loc[:,"id"] = int(dat_station[0])
                sta_one.loc[:,"lon"] = int(dat_station[1])
                sta_one.loc[:,"lat"] = int(dat_station[2])
                sta_all = pd.concat([sta_all, sta_one])

                if nline1 >= nline_all - 1:break
                nline0 = nline1
                dat_station = sta1.values[nline0,0:5]

            sta_all.loc[:,"time"] = time_file
            #print(sta_all)
            sta_all.columns = ["dtime","data0","id","lon","lat","time"]
            sta_all.loc[:,"level"] = 0
            sta = nmc_verification.nmc_vf_base.sta_data(sta_all)
            nmc_verification.nmc_vf_base.set_stadata_coords(sta, level=level, time=time)
            nmc_verification.nmc_vf_base.set_stadata_names(sta, data_name_list=[data_name])

            return sta
        else:
            print("不存在此文件！")
    except:
        exstr = traceback.format_exc()
        print(exstr)


def read_stadata_from_micaps1_2_8(filename, column, station=None, level=None,time=None, dtime=None, data_name='data0', drop_same_id=True):
    '''
    read_from_micaps1_2_8  读取m1、m2、m8格式的文件
    :param filename: 文件路径
    :param column: 选取哪列要素  4-len
    :param station: 站号 默认为None
    :param drop_same_id: 是否要删除相同id的行  默认为True
    :return:
    '''
    if os.path.exists(filename):
        sta1 = pd.read_csv(filename, skiprows=2, sep="\s+", header=None, usecols=[0, 1, 2,  column])
        # print(sta1)
        sta1.columns = ['id', 'lon', 'lat', 'data0']
        sta2 = nmc_verification.nmc_vf_base.basicdata.sta_data(sta1)

        if drop_same_id:
            sta2 = sta2.drop_duplicates(['id'])


        file = open(filename,'r')
        head = file.readline()
        head1 = file.readline()
        file.close()
        strs0 = head.split()
        strs = head1.split()

        y2 = ""
        if len(strs[0]) == 2:
            year = int(strs[0])
            if year >= 50:
                y2 = '19'
            else:
                y2 = '20'
        if len(strs[0]) == 1: strs[0] = "0" + strs[0]
        if len(strs[1]) == 1: strs[1] = "0" + strs[1]
        if len(strs[2]) == 1: strs[2] = "0" + strs[2]
        if len(strs[3]) == 1: strs[3] = "0" + strs[3]

        time_str = y2 + strs[0] + strs[1] + strs[2] + strs[3]
        time_file = nmc_verification.nmc_vf_base.tool.time_tools.str_to_time(time_str)
        if time is None:
            sta2.loc[:,'time'] = time_file
        else:
            sta2.loc[:,'time'] = time
        #print(strs0)
        if strs0[1] == "1":
            sta2.loc[:,"level"] = 0
            sta2.loc[:,"dtime"] = 0
        elif strs0[1] == "2":
            sta2.loc[:,"level"] = int(strs[4])
            sta2.loc[:,"dtime"] = 0
        elif strs0[1] == "8":
            sta2.loc[:,"level"] = 0
            sta2.loc[:,"dtime"] = int(strs[4])
        else:
            print(filename + "is not micaps第1、2、3、8类文件")

        nmc_verification.nmc_vf_base.set_stadata_coords(sta2,level= level,time = time,dtime= dtime)
        nmc_verification.nmc_vf_base.set_stadata_names(sta2,data_name_list=[data_name])
        if station is None:
            return sta2
        else:
            sta = nmc_verification.nmc_vf_base.put_stadata_on_station(sta2, station)
            return sta
    else:
        return None

def read_gds_ip_port(filename):
    file = open(filename)
    ip = file.readline()
    ip = ip.strip()
    port = int(file.readline())
    file.close()
    return ip,port

def read_stadata_from_gds(ip,port,filename,element_id = None,station = None,level=None,time=None, dtime=None, data_name='data0'):
    # ip 为字符串形式，示例 “10.20.30.40”
    # port 为整数形式
    # filename 为字符串形式 示例 "ECMWF_HR/TCDC/19083108.000"
    service = GDSDataService(ip, port)
    try:
        directory,fileName = os.path.split(filename)
        status, response = service.getData(directory, fileName)
        ByteArrayResult = DataBlock_pb2.ByteArrayResult()
        if status == 200:
            ByteArrayResult.ParseFromString(response)
            if ByteArrayResult is not None:
                byteArray = ByteArrayResult.byteArray
                nsta = struct.unpack("i", byteArray[288:292])[0]
                id_num = struct.unpack("h", byteArray[292:294])[0]
                id_tpye = {}
                for i in range(id_num):
                    element_id0 = struct.unpack("h", byteArray[294 + i * 4:296 + i * 4])[0]
                    id_tpye[element_id0] = struct.unpack("h", byteArray[296 + i * 4:298 + i * 4])[0]
                    if(element_id is None and element_id0 > 200 and element_id0 % 2 == 1):
                        element_id = element_id0
                station_data_dict = OrderedDict()
                index = 294 + id_num * 4
                type_lenght_dict = {1: 1, 2: 2, 3: 4, 4: 4, 5: 4, 6: 8, 7: 1}
                type_str_dict = {1: 'b', 2: 'h', 3: 'i', 4: 'l', 5: 'f', 6: 'd', 7: 'c'}

                for i in range(nsta):
                    one_station_dat = {}
                    one_station_dat["id"] =str(struct.unpack("i", byteArray[index: index + 4])[0])
                    index += 4
                    one_station_dat['lon'] =struct.unpack("f", byteArray[index: index + 4])[0]
                    index += 4
                    one_station_dat['lat'] =(struct.unpack("f", byteArray[index: index + 4])[0])
                    index += 4
                    value_num = struct.unpack("h", byteArray[index:index + 2])[0]
                    index += 2
                    values = {}
                    for j in range(value_num):
                        id = struct.unpack("h", byteArray[index:index + 2])[0]
                        index += 2
                        id_tpye0 = id_tpye[id]
                        dindex = type_lenght_dict[id_tpye0]
                        type_str = type_str_dict[id_tpye0]
                        value = struct.unpack(type_str, byteArray[index:index + dindex])[0]
                        index += dindex
                        values[id] = value
                    #print(values.keys())
                    if(element_id in values.keys()):
                        one_station_dat['data0'] =values[element_id]
                        station_data_dict[i] = one_station_dat
                sta = pd.DataFrame(station_data_dict).T

                sta2 = nmc_verification.nmc_vf_base.basicdata.sta_data(sta)
                filename1 = os.path.split(filename)[1].split(".")
                #print(filename1)
                time1 = nmc_verification.nmc_vf_base.tool.time_tools.str_to_time(filename1[0])
                sta2.loc[:,"level"] = 0
                sta2.loc[:,"time"] = time1
                sta2.loc[:,"dtime"] = int(filename1[1])
                nmc_verification.nmc_vf_base.set_stadata_coords(sta2, level=level, time=time, dtime=dtime)
                nmc_verification.nmc_vf_base.set_stadata_names(sta2, data_name_list=[data_name])
                if station is None:
                    return sta2
                else:
                    sta = nmc_verification.nmc_vf_base.put_stadata_on_station(sta2, station)
                    return sta
        return None
    except:
        exstr = traceback.format_exc()
        print(exstr)

def print_gds_file_values_names(ip,port,filename):
    # ip 为字符串形式，示例 “10.20.30.40”
    # port 为整数形式
    # filename 为字符串形式 示例 "ECMWF_HR/TCDC/19083108.000"
    value_id_list= []
    service = GDSDataService(ip, port)
    try:
        directory, fileName = os.path.split(filename)
        status, response = service.getData(directory, fileName)
        ByteArrayResult = DataBlock_pb2.ByteArrayResult()
        if status == 200:
            ByteArrayResult.ParseFromString(response)
            if ByteArrayResult is not None:
                byteArray = ByteArrayResult.byteArray
                nsta = struct.unpack("i", byteArray[288:292])[0]
                id_num = struct.unpack("h", byteArray[292:294])[0]
                id_tpye = {}
                for i in range(id_num):
                    element_id0 = struct.unpack("h", byteArray[294 + i * 4:296 + i * 4])[0]
                    id_tpye[element_id0] = struct.unpack("h", byteArray[296 + i * 4:298 + i * 4])[0]
                station_data_dict = OrderedDict()
                index = 294 + id_num * 4
                type_lenght_dict = {1: 1, 2: 2, 3: 4, 4: 4, 5: 4, 6: 8, 7: 1}
                type_str_dict = {1: 'b', 2: 'h', 3: 'i', 4: 'l', 5: 'f', 6: 'd', 7: 'c'}

                for i in range(nsta):
                    one_station_dat = {}
                    one_station_dat["id"] = str(struct.unpack("i", byteArray[index: index + 4])[0])
                    index += 4
                    one_station_dat['lon'] = struct.unpack("f", byteArray[index: index + 4])[0]
                    index += 4
                    one_station_dat['lat'] = (struct.unpack("f", byteArray[index: index + 4])[0])
                    index += 4
                    value_num = struct.unpack("h", byteArray[index:index + 2])[0]
                    index += 2
                    values = {}
                    for j in range(value_num):
                        id = struct.unpack("h", byteArray[index:index + 2])[0]
                        index += 2
                        id_tpye0 = id_tpye[id]
                        dindex = type_lenght_dict[id_tpye0]
                        type_str = type_str_dict[id_tpye0]
                        index += dindex
                        value_id_list.append(id)
            value_id_set = set(value_id_list)
            id_dict = nmc_verification.nmc_vf_base.gds_element_id_dict
            for value_id in value_id_set:
                for ele in id_dict.keys():
                    if value_id == id_dict[ele]:
                        print(ele)
    except:
        exstr = traceback.format_exc()
        print(exstr)

def read_stadata_from_micaps16(filename):
    if os.path.exists(filename):
        file = open(filename,'r')
        head = file.readline()
        head = file.readline()
        stationids = []
        row1 = []
        row2 = []
        row3 = []
        while(head is not None and head.strip() != ""):
            strs = head.split()
            stationids.append(strs[0])
            a = int(strs[1])
            b = a // 100 + (a % 100) /60
            row1.append(b)
            a = int(strs[2])
            b = a // 100 + (a % 100) /60
            row2.append(b)
            row3.append(float(strs[3]))
            head =  file.readline()

        row1 = np.array(row1)
        row2 = np.array(row2)
        row3 = np.array(row3)
        ids = np.array(stationids)
        dat = np.zeros((len(row1),4))
        dat[:,0] = ids[:]
        if(np.max(row2) > 90 or np.min(row2) <-90):
            dat[:,1] = row2[:]
            dat[:,2] = row1[:]
        else:
            dat[:,1] = row1[:]
            dat[:,2] = row2[:]
        dat[:,3] = row3[:]
        station = pd.DataFrame(dat, columns=['id','lon', 'lat', "data0"])
        station = nmc_verification.nmc_vf_base.sta_data(station)
        return station
    else:
        print(filename +" not exist")
        return None

def read_stadata_from_csv(filename):
    file = open(filename,"r")
    sta = pd.read_csv(file,parse_dates=['time'])
    sta.drop(sta.columns[[0]], axis=1, inplace=True)
    sta.dropna(axis=0, how='any', inplace=True)
    return sta