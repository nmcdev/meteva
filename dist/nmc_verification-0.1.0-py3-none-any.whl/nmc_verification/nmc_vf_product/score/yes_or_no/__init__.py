
import nmc_verification.nmc_vf_product.score.yes_or_no.threshold_one as threshold_one