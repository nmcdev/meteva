
import nmc_verification.nmc_vf_product.score.yes_or_no as yes_or_no