
import nmc_verification.nmc_vf_method.yes_or_no as yes_or_no
import nmc_verification.nmc_vf_method.continuous as continuous
import nmc_verification.nmc_vf_method.multi_category as multi_category