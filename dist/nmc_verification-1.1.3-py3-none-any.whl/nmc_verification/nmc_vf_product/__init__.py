import nmc_verification.nmc_vf_product.score as score
