#!/usr/bin/python3.6
# -*- coding:UTF-8 -*-
PI = 3.1415926
E = 2.7182818
ER = 6371
OMEGA = 0.00072722
IV = -999999