
def accuracy(ob,fo):
    #多分类预报准确率
    #ob 和fo是n×1的numpy数组，其中

    return

def hss(ob,fo):
    # 多分类预报hss评分
    return

def hk(ob,fo):
    # 多分类预报hss技巧评分

    return


