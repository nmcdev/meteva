#初始化io下边的四个模块，分别为读出格点数据，写入格点数据，读出站点数据，写入站点数据
from .read_griddata import *
from .write_griddata import *
from .read_stadata import *
from .write_stadata import *
#from . import DataBlock_pb2
#from .GDS_data_service import GDSDataService