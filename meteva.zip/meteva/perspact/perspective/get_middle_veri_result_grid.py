
def get_middle_veri_result_grid(grd,mpara):
    method = mpara["methods"][0]
